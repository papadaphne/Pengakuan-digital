
✅ PENGAKUAN DIGITAL - BUNDLE FINAL

📁 frontend/
  - index.html: Halaman penyambutan profesional
  - style.css: Desain modern dan menarik
  - script.js: Koneksi ke backend dinamis

📁 backend/
  - server.js: Endpoint QRIS dinamis Midtrans
  - Gunakan Render.com untuk hosting gratis
  - Ganti 'REPLACE_ME' dengan Server & Client Key kamu

🚀 Setelah pembayaran QRIS berhasil (min Rp10.000), user akan diarahkan ke halaman curhat.

